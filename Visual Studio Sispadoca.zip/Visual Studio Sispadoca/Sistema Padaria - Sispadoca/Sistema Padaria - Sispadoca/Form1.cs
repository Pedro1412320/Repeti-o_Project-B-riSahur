namespace Sistema_Padaria___Sispadoca
{
    public partial class FRMprincipal : Form
    {
        public FRMprincipal()
        {
            InitializeComponent();
        }

        private void pastaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void youtubeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairDoSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime Local = DateTime.Now;
            TSSLdatahora.Text = Local.ToString();
        }
    }
}
